def suma(num1,num2):
    print("la suma de ",num1,"+",num2," es ",num1+num2)

def resta(num1,num2):
    print("la resta de ",num1,"-",num2," es ",num1-num2)

def multiplicacion(num1,num2):
    print("la multiplicación de ",num1,"*",num2," es ",num1*num2)

def division(num1,num2):
    print("la division de ",num1,"/",num2," es ",num1/num2)

suma(5,7) 
resta(10,5)
multiplicacion(2,2)
division(8,2)