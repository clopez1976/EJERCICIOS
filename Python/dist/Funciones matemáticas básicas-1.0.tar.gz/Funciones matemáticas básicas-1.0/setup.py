#Setup para crear modulos de instalación
from setuptools import setup
setup(
name="Funciones matemáticas básicas",
version="1.0",
description="suma, resta, multiplicación y división",
author="AGC",
packages=["paquetes"]
)